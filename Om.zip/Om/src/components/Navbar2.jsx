import React from 'react'

const Navbar2 = () => {
    const Cotegories=()=>{
   
          let navLinks = [
          {
            id: 1,
            name: "Rates",
            link: "/",
          },
          {
            id: 2,
            name: "Navy Route",
            link: "/Navy ",
        
          },
          {
            id: 3,
            name: "Orders",
            link: "/Orders",
          },
        
          {
            id: 4,
            name: "",
            link: "/",
          },
         
        ];
    
       
      }
  return (
    <div>
      
    </div>
  )
}

export default Navbar2
