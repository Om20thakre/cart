import React from 'react'

const About = () => {
  return (
    <div className=' flex justify-center w-full h-screen bg-sky-blue '>
     


     



    </div>
  )
}

export default About
